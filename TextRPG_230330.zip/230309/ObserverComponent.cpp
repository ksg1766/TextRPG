#include "stdafx.h"
#include "ObserverComponent.h"
