#pragma once
#include "CreatureGO.h"

void MechFunc1(CCreatureGO* _cMonster, CCreatureGO* _cTarget);
void MechFunc2(CCreatureGO* _cMonster, CCreatureGO* _cTarget);